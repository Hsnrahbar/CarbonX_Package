CarbonX

CarbonX is an object-oriented Python package for simulating floating-catalyst chemical vapor deposition (FCCVD) reactors and predicting the gas-phase synthesis of metallic nanoparticles, carbon nanotubes, and graphene.

--------------------------------------------------

OVERVIEW

Carbon nanotubes (CNTs) exhibit exceptional electrical, optical, and mechanical properties, making them key materials for applications in energy storage, sensing, and advanced composites.

CarbonX provides a modular and extensible simulation framework to model CNT growth by capturing the interactions between chemical kinetics, catalyst evolution, and particle dynamics.

--------------------------------------------------

KEY FEATURES

- Object-oriented design
- Fully coupled multiphysics simulation
- Modular and extensible architecture
- Supports CNTs, graphene, amorphous carbon, and metal nanoparticles (e.g., Fe, Ni, Co)
- Time- and space-resolved simulations
- Integrated machine learning module for process optimization

--------------------------------------------------

ARCHITECTURE

Chemical Kinetics
Models gas-phase reactions.

Surface Kinetics
Handles catalyst activation, deactivation, and hydrogenation.

Particle Dynamics
Simulates nanoparticle inception, growth, coagulation, and sintering.

CNT Dynamics
Predicts CNT length, diameter, and wall number.

--------------------------------------------------

MACHINE LEARNING MODULE

Analyzes parametric maps to identify optimal synthesis conditions such as temperature, pressure, and catalyst concentration.

--------------------------------------------------

EXTENSIBILITY

Users can integrate custom:
- Gas-phase mechanisms
- Surface kinetics models
- Particle or CNT growth models

--------------------------------------------------

CONTACT

Hossein Rahbar
Email: rahbar.hosein@gmail.com
